# php-ecommerce
Simple and clear PHP shopping cart system based on e-commerce with Admin site.
Suitable for mini project.

Email alert : PHP Mailer
Insert your own email and password in confirmation_check.php file.
