<?php
session_start();
?>
       <!-- Navigation bar -->
<?php
   require_once ('includes/header.php');
?>
<!DOCTYPE html>
<html lang="zxx">
<head>
  <title>EndGam - Gaming Magazine Template</title>
  <meta charset="UTF-8">
  <meta name="description" content="EndGam Gaming Magazine Template">
  <meta name="keywords" content="endGam,gGaming, magazine, html">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Favicon -->
  <link href="img/favicon.ico" rel="shortcut icon"/>

  <!-- Google Font -->
  <link href="https://fonts.googleapis.com/css?family=Roboto:400,400i,500,500i,700,700i,900,900i" rel="stylesheet">


  <!-- Stylesheets -->
  <link rel="stylesheet" href="css/bootstrap.min.css"/>
  <link rel="stylesheet" href="css/font-awesome.min.css"/>
  <link rel="stylesheet" href="css/slicknav.min.css"/>
  <link rel="stylesheet" href="css/owl.carousel.min.css"/>
  <link rel="stylesheet" href="css/magnific-popup.css"/>
  <link rel="stylesheet" href="css/animate.css"/>

  <!-- Main Stylesheets -->
  <link rel="stylesheet" href="css/style.css"/>


  <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

</head>
<body>
 

  <!-- Page top section -->
  <section class="page-top-section set-bg" data-setbg="img/page-top-bg/3.jpg">
    <div class="page-info">
      <h2>Contact</h2>
      <div class="site-breadcrumb">
        <a href="">Home</a>  /
        <span>Contact</span>
      </div>
    </div>
  </section>
  <!-- Page top end-->


  <!-- Contact page -->
  <section class="contact-page">
    <div class="container">
      <div class="map"><iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d14376.077865872314!2d-73.879277264103!3d40.757667781624285!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sbd!4v1546528920522" style="border:0" allowfullscreen></iframe></div>
      <div class="row">
       <div class="col-lg-5 order-1 order-lg-2 contact-text text-white">
          <h3>Hello</h3>
          <p>Thankyou !</p>
          <div class="cont-info">
            <div class="ci-icon"><img src="img/icons/location.png" alt=""></div>
            <div class="ci-text">Main Str, no 23, Malaysia</div>
          </div>
          <div class="cont-info">
            <div class="ci-icon"><img src="img/icons/phone.png" alt=""></div>
            <div class="ci-text">+546 990221 123</div>
          </div>
          <div class="cont-info">
            <div class="ci-icon"><img src="img/icons/mail.png" alt=""></div>
            <div class="ci-text">ohnana@contact.com</div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- Contact page end-->




  <!-- Footer section -->
  <footer class="footer-section">
    <div class="container">
     
      <ul class="main-menu footer-menu">
        <li><a href="">Home</a></li>
        <li><a href="">Games</a></li>
        <li><a href="">Reviews</a></li>
        <li><a href="">News</a></li>
        <li><a href="">Contact</a></li>
      </ul>
      <div class="footer-social d-flex justify-content-center">
        <a href="#"><i class="fa fa-pinterest"></i></a>
        <a href="#"><i class="fa fa-facebook"></i></a>
        <a href="#"><i class="fa fa-twitter"></i></a>
        <a href="#"><i class="fa fa-dribbble"></i></a>
        <a href="#"><i class="fa fa-behance"></i></a>
      </div>
      <div class="copyright"><a href="">Colorlib</a> 2018 @ All rights reserved</div>
    </div>
  </footer>
  <!-- Footer section end -->


  <!--====== Javascripts & Jquery ======-->
  <script src="js/jquery-3.2.1.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.slicknav.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.sticky-sidebar.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/main.js"></script>

  </body>
</html>